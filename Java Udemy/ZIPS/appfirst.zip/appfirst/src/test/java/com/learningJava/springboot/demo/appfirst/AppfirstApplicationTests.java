package com.learningJava.springboot.demo.appfirst;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppfirstApplicationTests {

	@Test
	void contextLoads() {
	}

}
