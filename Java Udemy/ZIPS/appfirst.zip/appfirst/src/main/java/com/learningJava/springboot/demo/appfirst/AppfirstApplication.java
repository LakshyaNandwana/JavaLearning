package com.learningJava.springboot.demo.appfirst;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppfirstApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppfirstApplication.class, args);
	}

}
